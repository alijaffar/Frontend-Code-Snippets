=== Plugin Name ===
Contributors: alikm
Donate link: Block hundreds of spam domains, along with personal domains such as gmail.com in order to only receive work email domain submission. Must have Contact Form 7 activated to work.
Tags: comments, spam, contact form 7
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Block hundreds of spam domains and get only work emails, e.g. emails not using gmail.com or outlook.com and similar.

== Description ==

Validate your emails on the backend, and if you'd like the frontend version, feel free to check out the snippet here https://github.com/alijaffar/Frontend-Code-Snippets/blob/main/BusinessEmailsValudation.js

== Installation ==

This section describes how to install the plugin and get it working, assuming Contact Form 7 is already activated and used.

1. Upload `cf7spamdomains.zip` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Update your email input fields, from the default 'your-email' to simply: email

== Frequently Asked Questions ==

= What should my email input form field name be in CF7? =

It needs to be: email (not 'your-email')

== Screenshots ==

1. Example email validated for work emails only `screenshot.png`

== Changelog ==


= 0.1 =
This version is the initial working and tested version. We use 'email' as the main input field to validate, not 'your-email'. Admin options coming in the future, with the option to change this.